
Warning: readfile(): https:// wrapper is disabled in the server configuration by allow_url_fopen=0 in Command line code on line 1

Warning: readfile(https://getcomposer.org/installer): failed to open stream: no suitable wrapper could be found in Command line code on line 1
